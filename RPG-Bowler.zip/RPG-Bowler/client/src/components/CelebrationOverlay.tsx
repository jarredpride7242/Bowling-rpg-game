import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export type CelebrationType = "spare" | "strike" | "double" | "turkey" | null;

interface CelebrationOverlayProps {
  type: CelebrationType;
  onComplete?: () => void;
  enabled?: boolean;
}

const CELEBRATION_MS = 800;

const CELEBRATION_CONFIG = {
  spare: {
    text: "SPARE!",
    color: "text-chart-2",
    bg: "bg-chart-2/10",
    duration: CELEBRATION_MS,
    scale: 1.0,
  },
  strike: {
    text: "STRIKE!",
    color: "text-primary",
    bg: "bg-primary/10",
    duration: CELEBRATION_MS,
    scale: 1.0,
  },
  double: {
    text: "DOUBLE!",
    color: "text-chart-3",
    bg: "bg-chart-3/10",
    duration: CELEBRATION_MS,
    scale: 1.0,
  },
  turkey: {
    text: "TURKEY!",
    color: "text-destructive",
    bg: "bg-destructive/10",
    duration: CELEBRATION_MS,
    scale: 1.0,
  },
};

export function CelebrationOverlay({ type, onComplete, enabled = true }: CelebrationOverlayProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (type && enabled) {
      setVisible(true);
      const config = CELEBRATION_CONFIG[type];
      const timer = setTimeout(() => {
        setVisible(false);
        onComplete?.();
      }, config.duration);
      return () => clearTimeout(timer);
    }
  }, [type, enabled, onComplete]);

  if (!type || !enabled) return null;

  const config = CELEBRATION_CONFIG[type];

  return (
    <AnimatePresence mode="wait">
      {visible && (
        <motion.div
          key={type}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          className={`
            fixed top-16 left-1/2 -translate-x-1/2 z-50 pointer-events-none
            px-6 py-3 rounded-lg shadow-lg
            ${config.bg} backdrop-blur-sm border border-border/50
          `}
          data-testid={`celebration-${type}`}
        >
          <div className="text-center">
            <h2 className={`text-2xl font-bold tracking-wide ${config.color}`}>
              {config.text}
            </h2>
            {type === "turkey" && (
              <p className="text-xs text-muted-foreground mt-0.5">
                3 in a Row!
              </p>
            )}
            {type === "double" && (
              <p className="text-xs text-muted-foreground mt-0.5">
                2 in a Row!
              </p>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface LaneAnimationProps {
  isAnimating: boolean;
  pinsKnocked: number;
  isStrike: boolean;
  onComplete?: () => void;
}

export function LaneAnimation({ isAnimating, pinsKnocked, isStrike, onComplete }: LaneAnimationProps) {
  const [showBall, setShowBall] = useState(false);

  useEffect(() => {
    if (isAnimating) {
      setShowBall(true);
      const timer = setTimeout(() => {
        setShowBall(false);
        onComplete?.();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [isAnimating, onComplete]);

  if (!isAnimating && !showBall) return null;

  return (
    <div className="relative w-full h-32 bg-gradient-to-b from-amber-900/30 to-amber-800/20 rounded-md overflow-hidden mb-4">
      <div className="absolute inset-x-0 bottom-0 h-8 flex items-end justify-center pb-1">
        <div className="w-16 h-6 bg-muted/50 rounded-t-md flex items-center justify-center">
          <span className="text-xs text-muted-foreground">Pins</span>
        </div>
      </div>
      
      <div className="absolute left-1/2 top-0 w-px h-full bg-border/30" />
      <div className="absolute left-1/4 top-0 w-px h-full bg-border/20" />
      <div className="absolute right-1/4 top-0 w-px h-full bg-border/20" />
      
      <AnimatePresence>
        {showBall && (
          <motion.div
            initial={{ y: "100%", x: "-50%", scale: 1.2 }}
            animate={{ y: "10%", x: "-50%", scale: 0.6 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="absolute left-1/2 bottom-0"
          >
            <div className="w-8 h-8 rounded-full bg-primary shadow-lg" />
          </motion.div>
        )}
      </AnimatePresence>
      
      <AnimatePresence>
        {showBall && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="absolute inset-x-0 top-2 flex justify-center"
          >
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className={`text-2xl font-bold ${isStrike ? "text-primary" : "text-foreground"}`}
            >
              {isStrike ? "X" : pinsKnocked}
            </motion.span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
